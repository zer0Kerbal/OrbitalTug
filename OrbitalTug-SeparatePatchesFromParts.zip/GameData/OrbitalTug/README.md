# OrbitalTug
Continuation of Orbital Utility Vehicle by (first by nli2work), now continued by
LinuxGuruGamer with community support.

See ChangeLog.txt for details of mod changes

Extract to your KSP folder.

Requires 
ModuleManager @ http://forum.kerbalspaceprogram.com/index.php?/topic/50533-105-module-manager-2618-january-17th-with-even-more-sha-and-less-bug/

License
content licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.

You may modify for personal use. You may redistribute content with attribution to original author nli2work, plus any other attribution where required. You must redistribute under identical license, CC-BY-NC-SA. 

https://creativecommons.org/licenses/by-nc-sa/4.0/
